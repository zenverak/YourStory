All images drawn by Philipp Lenssen in late 1990s.
My website is outer-court.com . An appropriate link to the site
and credit by name would be appreciated in your projects.


License:
http://creativecommons.org/licenses/by/3.0/

For more info please see
http://blog.outer-court.com/archive/2006-08-08-n51.html
http://opengameart.org/content/700-sprites